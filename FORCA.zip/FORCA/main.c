#include <stdio.h>
#include <stdlib.h>
#include "forca.h"
#include "forca.c"
int main()
{
    printf("Desenvolvido por Henrique Valle e Leticia Marinho\n\n");
    NoSecreto * lstSecreta = inicializaListaSecreta();
    lstSecreta = carregaListaArquivo(lstSecreta,"palavras.dat");
    imprimeListaSecreta(lstSecreta);
    NoL * letras = inicializaListaSecreta();

    return 0;
}
