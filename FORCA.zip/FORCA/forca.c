#include <stdio.h>
#include <string.h>
#include "forca.h"

struct noSecreto {
int status;
char palavra[31];
char assunto[100];
int num;
struct noSecreto * prox;
};

struct noLetras
{
    char letra;
    int estado;
    struct noSecreto * proximo;
};

NoSecreto * inicializaListaSecreta()
{
    return NULL;
}

NoSecreto * inserePalavraSecreta(NoSecreto * l,char word[31],char subject[100])
{
  NoSecreto * novo;
  novo = (NoSecreto *) malloc(sizeof(NoSecreto));
  novo->status = 0;
  strcpy(novo->assunto,subject);
  strcpy(novo->palavra,word);
  novo->prox = l;
  l = novo;
  return l;
}
void imprimeListaSecreta(NoSecreto *l)
{
    NoSecreto * p;
    for (p = l; p!=NULL; p=p->prox)
    {
        printf("%0d | %30s | %30s | %d\n", p->status,p->palavra,p->assunto,p->num);
    }
}
NoSecreto * carregaListaArquivo(NoSecreto * l, char nomeArq[255])
{
    char palavra[31];
    char assunto[100];
    int n=0;
    FILE * fWords;
    fWords = fopen (nomeArq,"r");
    if (fWords==NULL){
        printf("Falha ao acessar base de dados!!!\n\n");
        exit(0);
    }
    while(!feof(fWords))
    {

      if(fscanf(fWords, "%s%s", palavra, assunto));
      {

          l = inserePalavraSecreta(l, palavra, assunto);
          l->num=n;

      }
        n++;
    }
    fclose(fWords);
    return l;
}
int quantos(NoSecreto * l)
{
    NoSecreto * p;
    int y=0;
    for (p = l; p!=NULL; p=p->prox)
    {
       y++;
    }
    return y;
}

NoSecreto * escolhealeatorio(NoSecreto * l)
{
    int t = quantos(l);
    t--;
    for(NoSecreto * u = l;u!=NULL;u = u->prox)
    {
        if((u->num = rand() % t) && (u->status = 0))
        {
            u->status = 1;
            return u;
        }
    }
}

/*NoL * crialetras(NoSecreto * l)
{
    NoSecreto * u = escolhealeatorio(l);

}*/

